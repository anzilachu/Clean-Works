$(document).ready(function(){
    $('#department , #clinic').on('change' , function(){

        var department = $('#department').val()
        var clinic = $('#clinic').val()

        $.ajax({
            type: 'POST',
            url: '/get-doctors/',
            data: {
                'department':department,
                'clinic':clinic,
            },
            success: function (response) {
                $('#doctor-select').html(response.data)
            },
            error: function () {
            }
        });
    })

    $('#appoinment-btn').on('click' , function(){
        var name = $('#name').val()
        var contact = $('#contact').val()
        var date = $('#date').val()
        var clinic = $('#clinic').val()
        var department = $('#department').val()
        var doctor = $('#doctor').val()
        
        $.ajax({
            type: 'POST',
            url: '/appoinment/',
            data: {
                'name':name, 'contact':contact, 'date':date, 'clinic':clinic, 'department':department,  'doctor': doctor
            },
            success: function (response) {
                $('#aform')[0].reset();
                $('#response').append('<div class="alert alert-success alert-dismissible fade show" role="alert"> Your Appointment Booked Successfully !! </div>');
            },
            error: function () {
                $('#response').append('<div class="alert alert-danger alert-dismissible fade show" role="alert"> en error occured </div>');
            }
        });
    })
})