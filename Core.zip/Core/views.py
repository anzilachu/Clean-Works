from django.shortcuts import render,redirect
from Core.pre_fun import setip,resize_image,random_string
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from Core.models import *
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse

# Create your views here.

#----------------------------------- DASHBOARD -----------------------------------#

@login_required
def dashboard(request):
    blogs = Blog.objects.filter(Status=1).count()
    clinics = Clinic.objects.filter(Status=1).count()
    departments = Department.objects.filter(Status=1).count()
    doctors = Doctor.objects.filter(Status=1).count()
    context = {
        'blogs' : blogs,
        'clinics' : clinics,
        'departments' : departments,
        'doctors' : doctors
    }
    return render(request,'Admin/dashboard.html',context)

#----------------------------------- CAREER ADD -----------------------------------#

@login_required
def career_add(request):
    last_career = Career.objects.last()
    clinics = Clinic.objects.filter(Status=1)

    if last_career:
        refer = f'REFERENCE-00{last_career.id+1}'
    else:
        refer = 'REFERENCE-001'

    if request.method == 'POST':
        title = request.POST.get('title')
        description = request.POST.get('description')
        deadline = request.POST.get('deadline')
        type = request.POST.get('type')
        experiance = request.POST.get('experiance')
        time = request.POST.get('time')
        days = request.POST.get('days')
        salery = request.POST.get('salery')
        vacancies = request.POST.get('vacancies') or None
        responsiblity = request.POST.get('responsiblity')
        requirements = request.POST.get('requirements')
        education = request.POST.get('education')

        clinic_id = request.POST.get('clinic')
        clinic = Clinic.objects.get(id=clinic_id)

        Career.objects.create(AddedBy=request.user,Ip=setip(request),Reference=refer,Title=title,Description=description,
                              Clinic=clinic,Deadline=deadline,Job_Type=type,Responsiblity=responsiblity,Requirements=requirements,
                              Education=education,Experiance=experiance,Working_Time=time,Working_Days=days,Salary=salery,Vacancies=vacancies)
        
        return redirect('career-list')

    return render(request,'Admin/career-add.html',{'refer':refer,'clinics':clinics})

#----------------------------------- CAREER LIST -----------------------------------#

@login_required
def career_list(request):
    careers = Career.objects.filter(Status=1).order_by('-id')
    p = Paginator(careers,25)
    page = request.GET.get('page')
    careers = p.get_page(page)
    nums = 'a' * careers.paginator.num_pages

    if request.method == 'POST':
        career_id = request.POST.get('career_id')
        career = Career.objects.get(id=career_id)
        career.Status = 0 
        career.save()
        return redirect('career-list')
    return render(request,'Admin/career-list.html',{'careers':careers,'nums':nums})

#----------------------------------------- FEATURED CATEGORIES -----------------------------------------------#

@csrf_exempt
def toggle_hide(request):
    if request.method == 'POST':
        career_id = request.POST.get('career_id')
        is_hide = request.POST.get('is_hide') == 'true'

        try:
            career = Career.objects.get(id=career_id)
            career.Hide = is_hide
            career.save()
            return JsonResponse({'success': True})
        except career.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'career not found'})

    return JsonResponse({'success': False, 'error': 'Invalid request'})

#----------------------------------- CAREER EDIT -----------------------------------#

@login_required
def career_edit(request,career_id):
    career = Career.objects.get(id=career_id)
    clinics = Clinic.objects.filter(Status=1)
    if request.method == 'POST':
        career.Title = request.POST.get('title')
        career.Description = request.POST.get('description')
        career.Deadline = request.POST.get('deadline')
        career.Job_Type = request.POST.get('type')
        career.Experiance = request.POST.get('experiance')
        career.Working_Time = request.POST.get('time')
        career.Working_Days = request.POST.get('days')
        career.Salary = request.POST.get('salery')
        career.Vacancies = request.POST.get('vacancies')
        career.Responsiblity = request.POST.get('responsiblity')
        career.Requirements = request.POST.get('requirements')
        career.Education = request.POST.get('education')

        clinic_id = request.POST.get('clinic')
        clinic = Clinic.objects.get(id=clinic_id)
        career.Clinic = clinic

        career.save()
        return redirect('career-list')
    return render(request,'Admin/career-edit.html',{'career':career,'clinics':clinics})

#----------------------------------- CAREER VIEW -----------------------------------#

@login_required
def job_view(request,job_id):
    job = Career.objects.get(id=job_id)
    applications = Application.objects.filter(Status=1)
    if request.method == 'POST':
        application_id = request.POST.get('application_id')
        application = Application.objects.get(id=application_id)
        application.Status = 0
        application.save()
        return redirect('job-view',job_id=job_id)
    return render(request,'Admin/job-view.html',{'job':job,'applications':applications})

#----------------------------------- BLOG ADD -----------------------------------#

@login_required
def add_blog(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        image = request.FILES.get('image')
        description = request.POST.get('description')
        seo_url = request.POST.get('seo_url')
        seo_title = request.POST.get('seo_title')
        seo_keywords = request.POST.get('seo_keywords')
        seo_description = request.POST.get('seo_description')

        if image:
            image_path = resize_image(image,800)
        else:
            image_path = None

        try:
            Blog.objects.get(Seo_Url=seo_url)
            seo_url = seo_url+random_string(6)
        except:
            pass
            
        Blog.objects.create(AddedBy=request.user,Ip=setip(request),Title=title,Description=description,Image=image_path,Seo_Url=seo_url,Seo_Title=seo_title,Seo_Description=seo_description,Seo_Keywords=seo_keywords)
        return redirect('list-blogs')
        
    return render(request,'Admin/blog-add.html')

#----------------------------------- BLOG LIST -----------------------------------#

@login_required
def list_blogs(request):
    blogs = Blog.objects.filter(Status=1)
    if request.method == 'POST':
        blog_id = request.POST.get('blog_id')
        blog = Blog.objects.get(id=blog_id)
        blog.Status = 0
        blog.save()
        return redirect('list-blogs')
    context = {
        'blogs' : blogs
    }
    return render(request,'Admin/blog-list.html',context)

#----------------------------------- BLOG EDIT -----------------------------------#

@login_required
def edit_blog(request,blog_id):
    blog = Blog.objects.get(id=blog_id)
    if request.method == 'POST':
        blog.Title = request.POST.get('title')
        if len(request.FILES) != 0:
            image = request.FILES['image']
            image_path = resize_image(image,800)
            blog.Image = image_path
        blog.Description = request.POST.get('description')

        url = request.POST.get('seo_url')

        obj = Blog.objects.filter(Seo_Url=url)

        if obj:
            pass
        else:
           blog.Seo_Url = request.POST.get('seo_url')

        # blog.Seo_Url = request.POST.get('seo_url')
        blog.Seo_Title = request.POST.get('seo_title')
        blog.Seo_Keywords = request.POST.get('seo_keywords')
        blog.Seo_Description = request.POST.get('seo_description')
        blog.save()
        return redirect('list-blogs')
    
    context = {
        "blog" : blog
    }
    
    return render(request,'Admin/blog-edit.html',context)

#------------------------------------------ VIEW BLOG -------------------------------------------------#

@login_required
def view_blog(request,blog_id):
    return render(request,'Admin/blog-view.html')

#--------------------------------------- DELETE BLOG IMAGE -------------------------------------------#

@login_required
def delete_blog_image(request,blog_id):
    blog = Blog.objects.get(id=blog_id)
    blog.Image.delete()
    return redirect('edit-blog' , blog_id=blog_id)

#------------------------------------------ CREATE ALBUM -------------------------------------------------#

@login_required
def create_album(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        thumbnail = request.FILES.get('thumbnail')
        images = request.FILES.getlist('images')
        seo_url = request.POST.get('seo_url')
        seo_title = request.POST.get('seo_title')
        seo_keywords = request.POST.get('seo_keywords')
        seo_description = request.POST.get('seo_description')

        if thumbnail:
            image_path = resize_image(thumbnail,800)
        else:
            image_path = None

        try:
            Album.objects.get(Seo_Url=seo_url)
            seo_url = seo_url+random_string(6)
        except:
            pass

        album = Album.objects.create(AddedBy=request.user,Ip=setip(request),Title=title,Thumbnail=image_path,
                                        Seo_Url=seo_url,Seo_Title=seo_title,Seo_Description=seo_description,Seo_Keywords=seo_keywords)
        
        for image in images:
            image_path = resize_image(image,800)
            Album_image.objects.create(Album=album,Image=image_path)

        images = Album_image.objects.filter(Album=album).count()
        album.Total_Images = images
        album.save()

        return redirect('list-albums')


    return render(request,'Admin/album-create.html')

#------------------------------------------ LIST ALBUMS -------------------------------------------------#

@login_required
def list_albums(request):
    albums = Album.objects.filter(Status=1)
    if request.method == 'POST':
        album_id = request.POST.get('album_id')
        album = Album.objects.get(id=album_id)
        album.Status = 0
        album.save()
        return redirect('list-albums')

    context = {
        'albums' : albums
    }
    return render(request,'Admin/albums-list.html',context)

#------------------------------------------ EDIT ALBUM -------------------------------------------------#

@login_required
def edit_album(request,album_id):
    album = Album.objects.get(id=album_id)
    images = Album_image.objects.filter(Album=album)

    if request.method == 'POST':
        if request.FILES.get('thumbnail'):
            thumbnail = request.FILES.get('thumbnail')
            thumbnail = thumbnail
            image_path = resize_image(thumbnail,800)
            album.Thumbnail = image_path

        if request.FILES.getlist('images'):
            images = request.FILES.getlist('images')
            for image in images:
                image_path = resize_image(image,800)
                Album_image.objects.create(Album=album,Image=image_path)
        
        album.Title = request.POST.get('title')
        # album.Seo_Url = request.POST.get('seo_url')

        url = request.POST.get('seo_url')

        obj = Album.objects.filter(Seo_Url=url)

        if obj:
            pass
        else:
           album.Seo_Url = request.POST.get('seo_url')

        album.Seo_Title = request.POST.get('seo_title')
        album.Seo_Keywords = request.POST.get('seo_keywords')
        album.Seo_Description = request.POST.get('seo_description')
        album.Total_Images = Album_image.objects.filter(Album=album).count()
        album.save()

        return redirect('list-albums')

    context = {
        'album' : album,
        'images' : images
    }
    return render(request,'Admin/album-edit.html',context)

#------------------------------------------ VIEW ALBUM -------------------------------------------------#

@login_required
def view_album(request,album_id):
    album = Album.objects.get(id=album_id)
    images = Album_image.objects.filter(Album=album)

    context = {
        'album' : album,
        'images' : images
    }
    return render(request,'Admin/album-view.html',context)

#------------------------------------------ DELETE ALBUM THUMBNAIL -------------------------------------------#

@login_required
def delete_album_thumbnail(request,album_id):
    album = Album.objects.get(id=album_id)
    album.Thumbnail.delete()
    return redirect('edit-album' ,album_id=album_id)

#------------------------------------------ DELETE ALBUM IMAGE -------------------------------------------#

@login_required
def delete_album_image(request):
    album_id = request.POST.get('album_id')
    image_id = request.POST.get('image_id')
    image = Album_image.objects.get(id=image_id)
    image.delete()
    return redirect('edit-album' ,album_id=album_id)

#------------------------------------------ ENQUIRIES -------------------------------------------#

@login_required
def enquiries(request):
    enquiries = Enquiry.objects.filter(Status=1).order_by('-id')
    if request.method == 'POST':
        enquiry_id = request.POST.get('enquiry_id')
        enquiry = Enquiry.objects.get(id=enquiry_id)
        enquiry.Status = 0
        enquiry.save()
        return redirect('enquiries')
    context = {
        'enquiries' : enquiries
    }
    return render(request,'Admin/enquiries.html',context)

#------------------------------------------ NEWSLATTERS -------------------------------------------#

@login_required
def newslatters(request):
    newslatters = Newslatter.objects.filter(Status=1).order_by('-id')
    if request.method == 'POST':
        newslatter_id = request.POST.get('newslatter_id')
        newslatter = Newslatter.objects.get(id=newslatter_id)
        newslatter.Status = 0
        newslatter.save()
        return redirect('newslatters')
    context = {
        'newslatters' : newslatters
    }
    return render(request,'Admin/newslatter.html',context)

#------------------------------------------ ADD CLINIC -------------------------------------------#

# @login_required
# def add_clinic(request):
#     if request.method == 'POST':
#         title = request.POST.get('title')
#         image = request.FILES.get('image')
#         description = request.POST.get('description')
#         phone = request.POST.get('phone')
#         email = request.POST.get('email')
#         wtime = request.POST.get('wtime')
#         loc = request.POST.get('loc')
#         seo_url = request.POST.get('seo_url')
#         seo_title = request.POST.get('seo_title')
#         seo_keywords = request.POST.get('seo_keywords')
#         seo_description = request.POST.get('seo_description')

#         if image:
#             image_path = resize_image(image,800)
#         else:
#             image_path = None

#         try:
#             Clinic.objects.get(Seo_Url=seo_url)
#             seo_url = seo_url+random_string(6)
#         except:
#             pass
            
#         Clinic.objects.create(AddedBy=request.user,Ip=setip(request),Name=title,Description=description,Image=image_path,Phone=phone,Email=email,Seo_Url=seo_url,Seo_Title=seo_title,Seo_Description=seo_description,Seo_Keywords=seo_keywords,Working_Time=wtime,Location=loc)
#         return redirect('list-clinics')
        
#     return render(request,'Admin/clinic-add.html')

from django.core.files.storage import default_storage
from django.core.files.base import ContentFile

@login_required
def add_clinic(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        image = request.FILES.get('image')
        description = request.POST.get('description')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        wtime = request.POST.get('wtime')
        loc = request.POST.get('loc')
        seo_url = request.POST.get('seo_url')
        seo_title = request.POST.get('seo_title')
        seo_keywords = request.POST.get('seo_keywords')
        seo_description = request.POST.get('seo_description')

        if image:  # Handling image upload
            # Adjust the path according to your upload_to field in the model
            image_path = 'images/' + image.name
            # Save the file using Django's default_storage
            default_storage.save(image_path, ContentFile(image.read()))
        else:
            image_path = None

        try:
            Clinic.objects.get(Seo_Url=seo_url)
            seo_url = seo_url + random_string(6)
        except Clinic.DoesNotExist:
            pass

        Clinic.objects.create(
            AddedBy=request.user,
            Ip=setip(request),
            Name=title,
            Description=description,
            Image=image_path,
            Phone=phone,
            Email=email,
            Seo_Url=seo_url,
            Seo_Title=seo_title,
            Seo_Description=seo_description,
            Seo_Keywords=seo_keywords,
            Working_Time=wtime,
            Location=loc
        )
        return redirect('list-clinics')

    return render(request, 'Admin/clinic-add.html')


#------------------------------------------ LIST CLINIC -------------------------------------------#

@login_required
def list_clinics(request):
    clinics = Clinic.objects.filter(Status=1).order_by('-id')
    if request.method == 'POST':
        clinic_id = request.POST.get('clinic_id')
        clinic = Clinic.objects.get(id=clinic_id)
        clinic.Status = 0
        clinic.save()
        return redirect('clinics')
    context = {
        'clinics' : clinics
    }
    return render(request,'Admin/clinic-list.html',context)

#------------------------------------------ EDIT CLINIC -------------------------------------------#

@login_required
def edit_clinic(request,clinic_id):
    clinic = Clinic.objects.get(id=clinic_id)
    if request.method == 'POST':
        clinic.Name = request.POST.get('title')
        clinic.Phone = request.POST.get('phone')
        clinic.Email = request.POST.get('email')
        clinic.Working_Time = request.POST.get('wtime')
        clinic.Location = request.POST.get('loc')
        clinic.Description = request.POST.get('description')
        if len(request.FILES) != 0:
            image = request.FILES['image']
            image_path = resize_image(image,800)
            clinic.Image = image_path

        url = request.POST.get('seo_url')

        obj = Clinic.objects.filter(Seo_Url=url)

        if obj:
            pass
        else:
           clinic.Seo_Url = request.POST.get('seo_url')

        # clinic.Seo_Url = request.POST.get('seo_url')
        clinic.Seo_Title = request.POST.get('seo_title')
        clinic.Seo_Keywords = request.POST.get('seo_keywords')
        clinic.Seo_Description = request.POST.get('seo_description')
        clinic.save()
        return redirect('list-clinics')
    
    context = {
        "clinic" : clinic
    }
    
    return render(request,'Admin/clinic-edit.html',context)

#------------------------------------------ VIEW CLINIC -------------------------------------------#

@login_required
def clinic_view(request,clinic_id):
    clinic = Clinic.objects.get(id=clinic_id)
    return render(request,'Admin/clinic-view.html',{'clinic':clinic})

#------------------------------------------ DELETE CLINIC IMAGE -------------------------------------------#

@login_required
def delete_clinic_image(request,clinic_id):
    clinic = Clinic.objects.get(id=clinic_id)
    clinic.Image.delete()
    return redirect('edit-clinic' , clinic_id=clinic_id)

#------------------------------------------ ADD DOCTOR -------------------------------------------#

@login_required
def add_doctor(request):

    last_doctor = Doctor.objects.last()
    departments = Department.objects.filter(Status=1)
    clinics = Clinic.objects.filter(Status=1)

    if last_doctor:
        refer = f'DOCTOR-{last_doctor.id+1}'
    else:
        refer = f'DOCTOR-1'

    if request.method == 'POST':
        name = request.POST.get('name')
        image = request.FILES.get('image')
        designation = request.POST.get('designation')
        speciality = request.POST.get('speciality')
        description = request.POST.get('description')

        department_id = request.POST.get('department')
        department = Department.objects.get(id=department_id)

        clinic_id = request.POST.get('clinic')
        clinic = Clinic.objects.get(id=clinic_id)

        if image:
            image_path = resize_image(image,800)
        else:
            image_path = None
            
        doctor = Doctor.objects.create(Name=name,Designation=designation,Speciality=speciality,Reference=refer,
                                       Description=description,Clinic=clinic,Image=image_path,Department=department)

        education = request.POST.getlist('education[]')
        expertise = request.POST.getlist('expertise[]')

        for edu in education:
            Institution.objects.create(Doctor=doctor,Name=edu)

        for exp in expertise:
            Expertise.objects.create(Doctor=doctor,Title=exp)


        return redirect('list-doctors')
    
    context = {
        'departments' : departments,
        'clinics' : clinics,
        'refer' : refer
    }
        
    return render(request,'Admin/doctor-add.html',context)

#------------------------------------------ LIST DOCTOR -------------------------------------------#

@login_required
def list_doctors(request):
    doctors = Doctor.objects.filter(Status=1).order_by('-id')
    if request.method == 'POST':
        doctor_id = request.POST.get('doctor_id')
        doctor = Doctor.objects.get(id=doctor_id)
        doctor.Status = 0
        doctor.save()
        return redirect('doctors')
    context = {
        'doctors' : doctors
    }
    return render(request,'Admin/doctor-list.html',context)

#------------------------------------------ EDIT DOCTOR -------------------------------------------#

@login_required
def edit_doctor(request,doctor_id):
    doctor = Doctor.objects.get(id=doctor_id)
    educations = Institution.objects.filter(Doctor=doctor)
    expertises = Expertise.objects.filter(Doctor=doctor)
    departments = Department.objects.filter(Status=1)
    clinics = Clinic.objects.filter(Status=1)

    if request.method == 'POST':
        doctor.Name = request.POST.get('name')
        doctor.Designation = request.POST.get('designation')
        doctor.Speciality = request.POST.get('speciality')

        department_id = request.POST.get('department')
        department = Department.objects.get(id=department_id)

        clinic_id = request.POST.get('clinic')
        clinic = Clinic.objects.get(id=clinic_id)

        doctor.Department = department
        doctor.Clinic = clinic

        if len(request.FILES) != 0:
            image = request.FILES['image']
            image_path = resize_image(image,800)
            doctor.Image = image_path

        education = request.POST.getlist('education[]')
        expertise = request.POST.getlist('expertise[]')

        educations.delete()
        expertises.delete()
        
        for edu in education:
            print(edu)
            if len(edu) != 0:
                Institution.objects.create(Doctor=doctor,Name=edu)

        for exp in expertise:
            print(exp)
            if len(exp) != 0:
                Expertise.objects.create(Doctor=doctor,Title=exp)

        doctor.save()

        return redirect('list-doctors')
    
    context = {
        "doctor" : doctor,
        'educations' : educations,
        'expertises' : expertises,
        'departments' : departments,
        'clinics' : clinics
    }
    
    return render(request,'Admin/doctor-edit.html',context)

#------------------------------------------ DELETE DOCTOR IMAGE -------------------------------------------#

@login_required
def delete_doctor_image(request,doctor_id):
    doctor = Doctor.objects.get(id=doctor_id)
    doctor.Image.delete()
    return redirect('edit-doctor' , doctor_id=doctor_id)

#------------------------------------------ DELETE DOCTOR IMAGE -------------------------------------------#

@login_required
def view_doctor(request,doctor_id):
    doctor = Doctor.objects.get(id=doctor_id)
    educations = Institution.objects.filter(Doctor=doctor)
    expertises = Expertise.objects.filter(Doctor=doctor)
    context = {
        'doctor' : doctor,
        'educations' : educations,
        'expertises' : expertises,
    }
    return render(request,'Admin/doctor-view.html',context)

#------------------------------------------ APPOINTMENTS -------------------------------------------#

@login_required
def appointments(request):
    appointments = Appointments.objects.filter(Status=1).order_by('-id')
    if request.method == 'POST':
        appointment_id = request.POST.get('appointment_id')
        appointment = Appointments.objects.get(id=appointment_id)
        appointment.Status = 0
        appointment.save()
        return redirect('appointments')
    return render(request,'Admin/appointments.html',{'appointments':appointments})

#------------------------------------------ DEPARTMENTS -------------------------------------------#

@login_required
def list_departments(request):
    departments = Department.objects.filter(Status=1).order_by('-id')
    if request.method == 'POST':
        department_id = request.POST.get('department_id')
        department = Department.objects.get(id=department_id)
        department.delete()
        return redirect('list-departments')
    context = {
        'departments' : departments
    }
    return render(request,'Admin/departments-list.html',context)

#------------------------------------------ FEATURED DEPARTMENTS -------------------------------------------#

@csrf_exempt
def toggle_featured(request):
    if request.method == 'POST':
        department_id = request.POST.get('department_id')
        is_featured = request.POST.get('is_featured') == 'true'

        try:
            department = Department.objects.get(id=department_id)
            department.Featured = is_featured
            department.save()
            return JsonResponse({'success': True})
        except department.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'department not found'})

    return JsonResponse({'success': False, 'error': 'Invalid request'})

#------------------------------------------ ADD DEPARTMENT -------------------------------------------------#

@login_required
def add_department(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        image = request.FILES.get('image')
        description = request.POST.get('description')
        seo_url = request.POST.get('seo_url')
        seo_title = request.POST.get('seo_title')
        seo_keywords = request.POST.get('seo_keywords')
        seo_description = request.POST.get('seo_description')

        if image:
            image_path = resize_image(image,800)
        else:
            image_path = None

        try:
            Department.objects.get(Seo_Url=seo_url)
            seo_url = seo_url+random_string(6)
        except:
            pass

        Department.objects.create(Name=name,Image=image_path,Description=description,Seo_Url=seo_url,Seo_Title=seo_title,Seo_Description=seo_description,Seo_Keywords=seo_keywords)

        return redirect('list-departments')

    return render(request,'Admin/department-create.html')

#------------------------------------------ EDIT DEPARTMENT -------------------------------------------------#

@login_required
def edit_department(request,department_id):
    department = Department.objects.get(id=department_id)
    if request.method == 'POST':
        department.Name = request.POST.get('name')
        if len(request.FILES) != 0:
            image = request.FILES['image']
            image_path = resize_image(image,800)
            department.Image = image_path

        department.Description = request.POST.get('description')

        url = request.POST.get('seo_url')

        obj = Department.objects.filter(Seo_Url=url)

        if obj:
            pass
        else:
           department.Seo_Url = request.POST.get('seo_url')

        # department.Seo_Url = request.POST.get('seo_url')
        department.Seo_Title = request.POST.get('seo_title')
        department.Seo_Keywords = request.POST.get('seo_keywords')
        department.Seo_Description = request.POST.get('seo_description')

        department.save()

        return redirect('list-departments')
    
    context = {
        "department" : department
    }
    
    return render(request,'Admin/department-edit.html',context)

#------------------------------------------ DELETE DEPARTMENT IMAGE -------------------------------------------#

@login_required
def delete_department_image(request,department_id):
    department = Department.objects.get(id=department_id)
    department.Image.delete()
    return redirect('edit-department' , department_id=department_id)

#------------------------------------------ EVENT ADD -------------------------------------------#

@login_required
def add_event(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        date = request.POST.get('date')
        time = request.POST.get('time')
        start_date = request.POST.get('start_date')
        start_time = request.POST.get('start_time')
        end_date = request.POST.get('end_date')
        end_time = request.POST.get('end_time')
        venue = request.POST.get('venue')
        image = request.FILES.get('image')
        description = request.POST.get('description')

        event = Event.objects.create(Title=title,Start_Date=start_date,Start_Time=start_time,End_Date=end_date,
                             End_Time=end_time,Date=date,Time=time,Venue=venue,Image=image,Description=description)
        
        attachment = request.FILES.getlist('attachments')
        for a in attachment:
            if str(a).endswith(('.png', '.jpg', '.jpeg','.PNG','.JPG','.JPEG')):
                format = 'image'
            else:
                format = 'file'
            attach = Event_Attachments(Event=event,Attachment=a,Name=a,Format=format)
            attach.save()

        return redirect('list-events')
    
    return render(request,'Admin/events-add.html')

#------------------------------------------ EVENT LIST -------------------------------------------#

@login_required
def list_event(request):
    events = Event.objects.filter(Status=1).order_by('-Start_Date')
    if request.method == 'POST':
        event_id = request.POST.get('event_id')
        event = Event.objects.get(id=event_id)
        event.Status = 0
        event.save()
        return redirect('list-events')
    return render(request,'Admin/events-list.html',{'events':events})

#------------------------------------------ EVENT EDIT -------------------------------------------#

@login_required
def edit_event(request,event_id):
    event = Event.objects.get(id=event_id)
    attachments = Event_Attachments.objects.all()
    if request.method == 'POST':
        if len(request.FILES) != 0:
            image = request.FILES.get('image')
            if image:
                image_path = resize_image(image,800)
                event.Image = image_path
        event.Title = request.POST.get('title')
        event.Venue = request.POST.get('venue')
        event.Description = request.POST.get('description')
        event.Date = request.POST.get('date')
        event.Time = request.POST.get('time')
        event.Start_Date = request.POST.get('start_date')
        event.Start_Time = request.POST.get('start_time')
        event.End_Date = request.POST.get('end_date')
        event.End_Time = request.POST.get('end_time')
        event.save()
        attachment = request.FILES.getlist('attachments')
        for a in attachment:
            if str(a).endswith(('.png', '.jpg', '.jpeg','.PNG','.JPG','.JPEG')):
                format = 'image'
            else:
                format = 'file'
            attach = Event_Attachments(Event=event,Attachment=a,Name=a,Format=format)
            attach.save()
        return redirect('list-events')
    return render(request,'Admin/events-edit.html',{'event':event,'attachments':attachments})

#------------------------------------------ DOWNLOAD ADD -------------------------------------------#

@login_required
def add_download(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        file = request.FILES.get('file')

        Uploades.objects.create(Title=title,File=file)

        return redirect('list-downloads')
    
    return render(request,'Admin/download-add.html')

#------------------------------------------ DOWNLOAD LIST -------------------------------------------#

@login_required
def list_download(request):
    downloads = Uploades.objects.filter(Status=1).order_by('-id')
    if request.method == 'POST':
        download_id = request.POST.get('download_id')
        download = Uploades.objects.get(id=download_id)
        download.delete()
        return redirect('list-downloads')
    return render(request,'Admin/download-list.html',{'downloads':downloads})

#------------------------------------------ DOWNLOAD EDIT -------------------------------------------#

@login_required
def edit_download(request,download_id):
    download = Uploades.objects.get(id=download_id)
    if request.method == 'POST':
        download.Title = request.POST.get('title')
        if len(request.FILES) != 0:
            file = request.FILES['file']
            download.File = file
        download.save()
        return redirect('list-downloads')
    return render(request,'Admin/download-edit.html',{'download':download})