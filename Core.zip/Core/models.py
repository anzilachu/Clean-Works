from django.db import models
from U_Auth.models import User

# Create your models here.

class Clinic(models.Model):
    Added_Date = models.DateTimeField(auto_now_add=True)
    Status = models.IntegerField(default=1)
    AddedBy = models.ForeignKey(User,on_delete=models.SET_NULL,null=True,related_name='clinic_added_user')
    Ip = models.GenericIPAddressField(null=True)

    Edited_Date = models.DateField(null=True)
    EditedBy = models.ForeignKey(User,on_delete=models.SET_NULL,null=True,related_name='clinic_edited_user')
    Edited_Ip = models.GenericIPAddressField(null=True)

    Status = models.IntegerField(default=1)
    Name = models.CharField(max_length=100)
    Description = models.TextField()
    Image = models.ImageField(upload_to='images',null=True)
    Phone = models.CharField(max_length=25,null=True)
    Email = models.EmailField(null=True)
    Working_Time = models.CharField(max_length=500,null=True)
    Location = models.CharField(max_length=500,null=True)

    Seo_Url = models.CharField(max_length=500,null=True,blank=True)
    Seo_Title = models.CharField(max_length=2000,blank=True,null=True)
    Seo_Description = models.TextField(blank=True,null=True)
    Seo_Keywords = models.CharField(max_length=2000,blank=True,null=True)


    def __str__(self):
        return self.Name

class Career(models.Model):
    Added_Date = models.DateTimeField(auto_now_add=True)
    Status = models.IntegerField(default=1)
    AddedBy = models.ForeignKey(User,on_delete=models.SET_NULL,null=True,related_name='wwu_added_user')
    Ip = models.GenericIPAddressField(null=True)

    Edited_Date = models.DateField(null=True)
    EditedBy = models.ForeignKey(User,on_delete=models.SET_NULL,null=True,related_name='wwu_edited_user')
    Edited_Ip = models.GenericIPAddressField(null=True)

    Reference = models.CharField(max_length=25)
    Title = models.CharField(max_length=100)
    Description = models.TextField(null=True)

    Clinic = models.ForeignKey(Clinic,on_delete=models.CASCADE)
    Deadline = models.DateField(null=True)
    Job_Type = models.CharField(max_length=150,null=True)

    Responsiblity = models.TextField(null=True)
    Requirements = models.TextField(null=True)
    Education = models.TextField(null=True)

    Experiance = models.CharField(max_length=100,null=True)
    Working_Time = models.CharField(max_length=100,null=True)
    Working_Days = models.CharField(max_length=100,null=True)
    Salary = models.CharField(max_length=100,null=True)
    Vacancies = models.IntegerField(null=True)

    Hide = models.BooleanField(default=False)

    def __str__(self):
        return self.Title
    

class Blog(models.Model):
    Added_Date = models.DateTimeField(auto_now_add=True)
    Status = models.IntegerField(default=1)
    AddedBy = models.ForeignKey(User,on_delete=models.SET_NULL,null=True,related_name='blog_added_user')
    Ip = models.GenericIPAddressField(null=True)

    Edited_Date = models.DateField(null=True)
    EditedBy = models.ForeignKey(User,on_delete=models.SET_NULL,null=True,related_name='blog_edited_user')
    Edited_Ip = models.GenericIPAddressField(null=True)

    Title = models.CharField(max_length=500)
    Description = models.TextField()
    Image = models.ImageField(upload_to='images',null=True)
    
    Seo_Url = models.CharField(max_length=500,null=True,blank=True)
    Seo_Title = models.CharField(max_length=2000,blank=True,null=True)
    Seo_Description = models.TextField(blank=True,null=True)
    Seo_Keywords = models.CharField(max_length=2000,blank=True,null=True)

    def __str__(self):
        self.Title

class Album(models.Model):
    Added_Date = models.DateTimeField(auto_now_add=True)
    Status = models.IntegerField(default=1)
    AddedBy = models.ForeignKey(User,on_delete=models.SET_NULL,null=True,related_name='album_added_user')
    Ip = models.GenericIPAddressField(null=True)

    Edited_Date = models.DateField(null=True)
    EditedBy = models.ForeignKey(User,on_delete=models.SET_NULL,null=True,related_name='album_edited_user')
    Edited_Ip = models.GenericIPAddressField(null=True)

    Title = models.CharField(max_length=500)
    Thumbnail = models.ImageField(upload_to='gallery',null=True)
    Total_Images = models.IntegerField(default=0)
    
    Seo_Url = models.CharField(max_length=500,null=True,blank=True)
    Seo_Title = models.CharField(max_length=2000,blank=True,null=True)
    Seo_Description = models.TextField(blank=True,null=True)
    Seo_Keywords = models.CharField(max_length=2000,blank=True,null=True)

    def __str__(self):
        self.Title


class Album_image(models.Model):
    Album = models.ForeignKey(Album, on_delete=models.CASCADE)
    Image = models.FileField(upload_to="album_images")

    def __str__(self):
        return self.Album.Title   

class Enquiry(models.Model):
    Status = models.IntegerField(default=1)
    Date = models.DateField(auto_now_add=True)
    Name = models.CharField(max_length=100)
    Contact = models.CharField(max_length=100)
    Subject = models.CharField(max_length=100,null=True)
    Message = models.TextField() 

    def __str__(self):
        return self.Name   
    
class Newslatter(models.Model):
    Status = models.IntegerField(default=1)
    Date = models.DateField(auto_now_add=True)
    Email = models.EmailField()

    def __str__(self):
        return self.Email     

class Department(models.Model):
    Status = models.IntegerField(default=1)
    Featured = models.BooleanField(default=False)
    Name = models.CharField(max_length=100)
    Image = models.ImageField(upload_to='images',null=True)
    Description = models.TextField(null=True)

    Seo_Url = models.CharField(max_length=500,null=True,blank=True)
    Seo_Title = models.CharField(max_length=2000,blank=True,null=True)
    Seo_Description = models.TextField(blank=True,null=True)
    Seo_Keywords = models.CharField(max_length=2000,blank=True,null=True)

    def __str__(self):
        return self.Name

class Doctor(models.Model):
    Added_Date = models.DateTimeField(auto_now_add=True)
    Status = models.IntegerField(default=1)
    AddedBy = models.ForeignKey(User,on_delete=models.SET_NULL,null=True,related_name='doctor_added_user')
    Ip = models.GenericIPAddressField(null=True)

    Edited_Date = models.DateField(null=True)
    EditedBy = models.ForeignKey(User,on_delete=models.SET_NULL,null=True,related_name='doctor_edited_user')
    Edited_Ip = models.GenericIPAddressField(null=True)

    Reference = models.CharField(max_length=25)
    Name = models.CharField(max_length=100)
    Image = models.ImageField(upload_to='images',null=True)
    Designation = models.CharField(max_length=100)
    Speciality = models.CharField(max_length=100)
    Department = models.ForeignKey(Department,on_delete=models.CASCADE)
    Description = models.TextField(null=True)
    Clinic = models.ForeignKey(Clinic,on_delete=models.CASCADE)

    def __str__(self):
        return self.Name


class Institution(models.Model):
    Doctor = models.ForeignKey(Doctor,on_delete=models.CASCADE)
    Name = models.CharField(max_length=100)
    Course = models.CharField(max_length=100,null=True)

    def __str__(self):
        return self.Name
    
class Expertise(models.Model):
    Doctor = models.ForeignKey(Doctor,on_delete=models.CASCADE)
    Title = models.CharField(max_length=100)

    def __str__(self):
        return self.Title
    

class Appointments(models.Model):
    Status = models.IntegerField(default=1)
    Name = models.CharField(max_length=100)
    Contact = models.CharField(max_length=100)
    Date = models.DateField()
    Clinic  = models.ForeignKey(Clinic,on_delete=models.CASCADE)
    Department = models.ForeignKey(Department,on_delete=models.CASCADE)
    Doctor = models.ForeignKey(Doctor,on_delete=models.CASCADE)

    def __str__(self):
        return self.Name
    
class Application(models.Model):
    Status = models.IntegerField(default=1)
    Name = models.CharField(max_length=100)
    Email = models.EmailField(null=True)
    Phone = models.CharField(max_length=25)
    Location = models.CharField(max_length=50,null=True)
    CV = models.FileField(upload_to='files')

    def __str__(self):
        return self.Name
    

class Event(models.Model):
    Status = models.IntegerField(default=1)
    Title = models.CharField(max_length=225)
    Venue = models.CharField(max_length=225,null=True)
    Image = models.ImageField(upload_to='images',null=True)
    Description = models.TextField(null=True)
    Date = models.DateField()
    Time = models.TimeField()
    Start_Date = models.DateField()
    Start_Time = models.TimeField()
    End_Date = models.DateField()
    End_Time = models.TimeField()

    def __str__(self):
        return self.Title
    
class Event_Attachments(models.Model):
    Event = models.ForeignKey(Event,on_delete=models.CASCADE)
    Attachment = models.FileField(upload_to='update-files')
    Name = models.TextField(null=True)
    Format = models.TextField(null=True)

    def __str__(self):
        return self.Name
    
class Uploades(models.Model):
    Status = models.IntegerField(default=1)
    Date = models.DateField(auto_now_add=True)
    Title = models.CharField(max_length=225)
    File = models.FileField(upload_to='files')

    def __str__(self):
        return self.Title