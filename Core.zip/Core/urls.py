from django.urls import path
from Core.views import *

urlpatterns = [
    path('',dashboard,name='dashboard'),

    #Career Urls
    path('career-add/',career_add,name='career-add'),
    path('career-list/',career_list,name='career-list'),
    path('career-edit/<int:career_id>/',career_edit,name='career-edit'),
    path('job-view/<int:job_id>',job_view,name='job-view'),
    path('enquiries',enquiries,name='enquiries'),
    path('appointments',appointments,name='appointments'),
    path('newslatters/',newslatters,name='newslatters'),
    path('toggle_hide/',toggle_hide,name='toggle_hide'),
    path('toggle_featured/', toggle_featured, name='toggle_featured'),

    #------------------------ BLOG URL ----------------------#
    path('add-blog',add_blog,name='add-blog'),
    path('list-blogs',list_blogs,name='list-blogs'),
    path('edit-blog/<int:blog_id>/',edit_blog,name='edit-blog'),
    path('view-blog/<int:blog_id>/',view_blog,name='view-blog'),
    path('delete-blog-image/<int:blog_id>/',delete_blog_image,name='delete-blog-image'),

    #------------------------ GALLERY URL ----------------------#
    path('create-gallery/',create_album,name='create-gallery'),
    path('list-albums',list_albums,name='list-albums'),
    path('edit-album/<int:album_id>/',edit_album,name='edit-album'),
    path('view-album/<int:album_id>/',view_album,name='view-album'),
    path('delete-album-thumbnail/<int:album_id>/',delete_album_thumbnail,name='delete-album-thumbnail'),
    path('delete-album-image',delete_album_image,name='delete-album-image'),

    #------------------------ CLINIC URL ----------------------#
    path('add-clinic/',add_clinic,name='add-clinic'),
    path('list-clinics/',list_clinics,name='list-clinics'),
    path('edit-clinic/<int:clinic_id>/',edit_clinic,name='edit-clinic'),
    path('delete-clinic-image/<int:clinic_id>/',delete_clinic_image,name='delete-clinic-image'),
    path('view-clinic/<int:clinic_id>/',clinic_view,name='clinic-view'),

    #------------------------ DOCTOR URL ----------------------#
    path('list-doctors/',list_doctors,name='list-doctors'),
    path('add-doctor',add_doctor,name='add-doctor'),
    path('edit-doctor/<int:doctor_id>/',edit_doctor,name='edit-doctor'),
    path('delete-doctor-image/<int:doctor_id>/',delete_doctor_image,name='delete-doctor-image'),
    path('view-doctor/<int:doctor_id>/',view_doctor,name='view-doctor'),

    #------------------------ DEPARTMENT URL ----------------------#
    path('list-departments/',list_departments,name='list-departments'),
    path('create-department/',add_department,name='create-department'),
    path('edit-department/<int:department_id>/',edit_department,name='edit-department'),
    path('delete-department-image/<int:department_id>/',delete_department_image,name='delete-department-image'),

    #------------------------ EVENT URL ----------------------#
    path('add-event/',add_event,name='add-event'),
    path('list-events/',list_event,name='list-events'),
    path('edit-event/<int:event_id>/',edit_event,name='edit-event'),

    #------------------------ DOWNLOAD URL ----------------------#
    path('add-download/',add_download,name='add-download'),
    path('list-downloads/',list_download,name='list-downloads'),
    path('edit-download/<int:download_id>/',edit_download,name='edit-download')
]