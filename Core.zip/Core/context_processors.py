from Core.models import Department,Clinic

def context_processor(request):
    # Define your context variables
    departments = Department.objects.filter(Status=1)
    clinics = Clinic.objects.filter(Status=1)
    featured_departments = Department.objects.filter(Status=1,Featured=True)
    
    context = {
        'header_departments' : departments,
        'clinics' : clinics,
        'featured_departments' : featured_departments
    }
    return context