from django.shortcuts import render,redirect
from Core.models import *
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from datetime import date,datetime
from django.db.models import Q
import pytz
from django.utils import timezone

# Specify the Kuwait timezone

def home(request):
    #setting timezone to kuwait
    kuwait_timezone = pytz.timezone('Asia/Kuwait')
    current_time_in_utc = timezone.now()
    current_time_in_kuwait = current_time_in_utc.astimezone(kuwait_timezone)
    today_date = current_time_in_kuwait.date()
    current_time = current_time_in_kuwait.time()
    
    news = Blog.objects.filter(Status=1).order_by('-id')[:5]
    clinics = Clinic.objects.filter(Status=1)
    departments = Department.objects.filter(Status=1)
    doctors = Doctor.objects.filter(Status=1)
    # events = Event.objects.filter(Q(Start_Date__lte=today_date) & Q(End_Date__gte=today_date) | Q(Start_Date=today_date, End_Time__gt=current_time),Status=1)

    events = Event.objects.filter(
        Start_Date__lte=today_date,
        Start_Time__lte=current_time,
        End_Date__gte=today_date,
        # End_Time__gte=current_time
    ).exclude(Status=0)
    
    context = {
        'newses' : news,
        'clinics' : clinics,
        'departments' : departments,
        'doctors' : doctors,
        'events' : events,
        'today_date' : today_date,
        'current_time' : current_time
    }
    return render(request,'Frontpage/home.html',context)

def index(request):
    #setting timezone to kuwait
    kuwait_timezone = pytz.timezone('Asia/Kuwait')
    current_time_in_utc = timezone.now()
    current_time_in_kuwait = current_time_in_utc.astimezone(kuwait_timezone)
    today_date = current_time_in_kuwait.date()
    current_time = current_time_in_kuwait.time()


    
    news = Blog.objects.filter(Status=1).order_by('-id')[:5]
    clinics = Clinic.objects.filter(Status=1)
    departments = Department.objects.filter(Status=1)
    doctors = Doctor.objects.filter(Status=1)
    # events = Event.objects.filter(Q(Start_Date__lte=today_date) & Q(End_Date__gte=today_date) | Q(Start_Date=today_date, End_Time__gt=current_time),Status=1)

    events = Event.objects.filter(
        Start_Date__lte=today_date,
        Start_Time__lte=current_time,
        End_Date__gte=today_date,
        # End_Time__gte=current_time
    )
    
    context = {
        'newses' : news,
        'clinics' : clinics,
        'departments' : departments,
        'doctors' : doctors,
        'events' : events,
        'today_date' : today_date,
        'current_time' : current_time
    }
    return render(request,'Frontpage/index.html',context)

def about(request):
    return render(request,'Frontpage/about.html')

def ceo_message(request):
    return render(request,'Frontpage/ceo-message.html')

def clinic_mirqab(request):
    return render(request,'Frontpage/clinic.html')

def view_clinic(request,url):
    clinic = Clinic.objects.get(Seo_Url=url)
    doctors = Doctor.objects.filter(Clinic=clinic)
    return render(request,'Frontpage/clinic.html',{'clinic':clinic,'doctors':doctors})

def doctor_details(request,refer):
    doctor = Doctor.objects.get(Reference=refer)
    educations = Institution.objects.filter(Doctor=doctor).exclude(Name='')
    expertises = Expertise.objects.filter(Doctor=doctor).exclude(Title='')

    context = {
        'doctor':doctor,
        'educations' : educations,
        'expertises' : expertises
    }
    return render(request,'Frontpage/doctor_details.html',context)

def internal_medicine(request):
    return render(request,'Frontpage/internal-medicine.html')

def department(request,url):
    department = Department.objects.get(Seo_Url=url)
    departments = Department.objects.exclude(Seo_Url=url)
    doctors = Doctor.objects.filter(Department=department)
    context = {
        'departments' : departments,
        'department' : department,
        'doctors' : doctors
    }
    return render(request,'Frontpage/department-details.html',context)

def experts(request):
    doctors = Doctor.objects.filter(Status=1)
    context = {
        'doctors' : doctors
    }
    return render(request,'Frontpage/experts.html',context)

def work_with_us(request):
    jobs = Career.objects.filter(Status=1 , Hide=False)
    context = {
        'jobs' : jobs
    }
    return render(request,'Frontpage/work-with-us.html',context)

def work_with_us_details(request,refer):
    job = Career.objects.get(Reference=refer)
    context = {
        'job' : job
    }
    return render(request,'Frontpage/work-with-us-details.html',context)

def news(request):
    news = Blog.objects.filter(Status=1).order_by('-id')
    context = {
        'newses' : news
    }
    return render(request,'Frontpage/news.html',context)

def news_details(request,url):
    news = Blog.objects.get(Seo_Url=url)
    recent_news = Blog.objects.filter(Status=1).exclude(id=news.id).order_by('-id')[:3]

    context = {
        'news' : news,
        'recent_news' : recent_news
    }

    return render(request,'Frontpage/news-details.html',context)

def gallery(request):
    albums = Album.objects.filter(Status=1).order_by('-id')

    context = {
        'albums' : albums
    }

    return render(request,'Frontpage/gallery.html',context)

def view_gallery(request,url):
    album = Album.objects.get(Seo_Url=url)
    images = Album_image.objects.filter(Album=album)

    context = {
        'album' : album,
        'images' : images
    }

    return render(request,'Frontpage/gallery-view.html',context)

def contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        contact = request.POST.get('contact')
        subject = request.POST.get('subject')
        message = request.POST.get('message')

        Enquiry.objects.create(Name=name,Contact=contact,Subject=subject,Message=message)
        messages.success(request,'enquiry submited successfully ...!')
        return redirect('contact')
    return render(request,'Frontpage/contact.html')

def application_form(request,refer):
    job = Career.objects.get(Reference=refer)
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        location = request.POST.get('location')
        cv = request.FILES.get('cv')

        Application.objects.create(Name=name,Email=email,Phone=phone,Location=location,CV=cv)
        messages.success(request,'application submitted successfully !!')
        return redirect('application-form' , refer=refer)
    return render(request,'Frontpage/application-form.html',{'job':job})

@csrf_exempt
def appoinment(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        contact = request.POST.get('contact')
        date = request.POST.get('date')

        clinic_id = request.POST.get('clinic')
        department_id = request.POST.get('department')
        doctor_id = request.POST.get('doctor')

        clinic = Clinic.objects.get(id=clinic_id)
        department = Department.objects.get(id=department_id)
        doctor = Doctor.objects.get(id=doctor_id)

        try:
            Appointments.objects.create(Name=name,Contact=contact,Date=date,Clinic=clinic,
                                        Department=department,Doctor=doctor)
            
            message = 'Appoiment enquiry submited successfully'
        except:
            message = 'something went wrong cant submit appoinment'

        return JsonResponse({'message':message})
    
@csrf_exempt
def add_newslatter(request):
    if request.method == 'POST':
        email = request.POST.get('email')

        try:
            Newslatter.objects.create(Email=email)
            
            message = 'newslatter submitted successfully'
        except:
            message = 'something went wrong cant submit newslatter'

        return JsonResponse({'message':message})
    
@csrf_exempt
def get_doctors(request):
    data = '<div class="nice-select open" tabindex="0"><span class="current">Select Doctor</span><ul class="list"><li data-value class="option selected focus">Select Doctor</li>'
    test = '<div class="nice-select open" tabindex="0"><span class="current">Select Doctor</span><ul class="list"><li data-value class="option selected focus">Select Doctor</li><ul/>::after</div>'
    if request.method == 'POST':
        department_id = request.POST.get('department')
        clinic_id = request.POST.get('clinic')
        
        clinic = Clinic.objects.get(id=clinic_id)
        department = Department.objects.get(id=department_id)

        if clinic and department:
            doctors = Doctor.objects.filter(Clinic=clinic,Department=department,Status=1)

        for doctor in doctors:
            data += f'<option value="{doctor.id}">{doctor.Name}</option>'

        data += '<ul/></div>'

        return JsonResponse({'data':data})
    

def download(request):
    uploads = Uploades.objects.all()
    return render(request,'Frontpage/download-news.html',{'uploads':uploads})

def view_event(request,event_id):
    kuwait_timezone = pytz.timezone('Asia/Kuwait')
    current_time_in_utc = timezone.now()
    current_time_in_kuwait = current_time_in_utc.astimezone(kuwait_timezone)
    today_date = current_time_in_kuwait.date()
    current_time = current_time_in_kuwait.time()
    event = Event.objects.get(id=event_id)

    events = Event.objects.filter(
        Start_Date__lte=today_date,
        Start_Time__lte=current_time,
        End_Date__gte=today_date,
        # End_Time__gte=current_time
    ).exclude(id=event_id).exclude(Status=0)

    attachments = Event_Attachments.objects.filter(Event=event)

    context = {
        'event' : event,
        'events' : events,
        'attachments' : attachments
    }
    return render(request,'Frontpage/view-event.html',context)